"""Replay saved native physiology through the unmodified ExternalSession.
Actual primary text (including errors and deletion) is the model context.
Only UI waiting is zeroed; no physiological or decoder math is replaced.
"""
import argparse,json,time
from pathlib import Path
import numpy as np
from common import setup,phrases,load_model

def distance(a,b):
 row=list(range(len(b)+1))
 for i,x in enumerate(a,1):
  new=[i]
  for j,y in enumerate(b,1):new.append(min(new[-1]+1,row[j]+1,row[j-1]+(x!=y)))
  row=new
 return row[-1]

def main(a):
 root=setup(a.speller)
 from eeg_speller.external.controller import ExternalSession
 from eeg_speller.external.transport import MemoryTransport
 model,rep,cfg=load_model(root,a.models,a.model,a.device)
 cfg=cfg.model_copy(update={'mode':{'llm':'off' if a.model=='uniform' else 'on'},
      'stimulus':{**cfg.stimulus,'pause_ms':0},
      'external':{**cfg.external,'stop_confidence':None,'keyboard_wait_s':0}})
 out=Path(a.output);bank=dict(np.load(out/'signals.npz'));rows=phrases(a.data)
 dest=out/'session_runs'/a.model;records=[]
 outlog=out/(a.model+'_sessions.jsonl')
 with outlog.open('w') as stream:
  for seed in range(a.seeds):
   offset=0
   for ri,r in enumerate(rows):
    text=r['text'];tr=MemoryTransport();n_epochs=[0];visits={}
    session=ExternalSession(cfg.model_copy(update={'participant_id':f'{a.model}-{seed}','task_id':r['id']}),text,dest,transport=tr,model_factory=lambda kind,c:model,profile='native-study-replay',replay_of='signals.npz',passport={'source':'shipped headless_sim','seed':seed,'repetitions':5,'d_prime':1.2,'UI_waits':'accelerated'})
    def deliver(msg):
     if msg['cmd']!='epoch_start':return
     n_epochs[0]+=1
     if n_epochs[0]>len(text)*3:
      session.request_stop('epoch_budget');return
     idx=offset+session.target_index
     visit=visits.get(idx,0);visits[idx]=visit+1
     signal_seed=seed+5*visit
     if signal_seed>=len(bank['p']):
      session.request_stop('replay_bank_exhausted');return
     p=bank['p'][signal_seed,idx,2].tolist()
     tr.deliver('likelihood',{'epoch':msg['epoch'],'p':p,'final':True,'info':{'bank_position':idx,'seed':signal_seed,'visit':visit,'flashes_in_recording':60}},module='recorded-native-simulator')
    tr.listeners.append(deliver)
    start=time.perf_counter();session.start().wait_finished(1200)
    if not session.finished:
     session.request_stop('study_timeout');session.wait_finished(10)
    if session.error:raise RuntimeError(session.error)
    observed=session.primary.value;edits=distance(text,observed)
    integrity=json.loads((session.storage.directory/'derived/integrity.json').read_text())
    row={'model':a.model,'id':r['id'],'seed':seed,'target':text,'text':observed,'edits':edits,'n':len(text),'CER':edits/len(text),
         'correct_decisions':sum(x['correct'] is True for x in session.log),'decisions':len(session.log),
         'deletions':sum(x['decided']=='⌫' for x in session.log),'end_reason':session.end_reason,'wall_s':time.perf_counter()-start,
         'directory':str(session.storage.directory.relative_to(out)),'integrity_complete':integrity['complete']}
    stream.write(json.dumps(row,ensure_ascii=False)+'\n');stream.flush();records.append(row)
    print(a.model,seed,r['id'],round(row['CER']*100,2),observed,flush=True)
    offset+=len(text)
 summary={'model':a.model,'context':'own_primary','phrases':len(records),'chars':sum(r['n'] for r in records),
          'CER':sum(r['edits'] for r in records)/sum(r['n'] for r in records),'incomplete':sum(r['end_reason']!='target_finished' for r in records),
          'integrity_ok':all(r['integrity_complete'] for r in records)}
 (out/(a.model+'_sessions_summary.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(summary,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser()
 for key in ('speller','models','model','data','output'):p.add_argument('--'+key,required=True)
 p.add_argument('--device',default='cpu');p.add_argument('--seeds',type=int,default=5)
 main(p.parse_args())
