"""Paired per-character decoding through production likelihood parser and fusion."""
import argparse,json
from pathlib import Path
import numpy as np
from common import setup,load_model

def main(a):
 root=setup(a.speller)
 from eeg_speller.external.controller import likelihood_vector
 from eeg_speller.epoch.plugins import PluginFusion
 from eeg_speller.physiology.base import PhysiologyObservation
 from eeg_speller.core.distributions import SymbolDistribution,Repertoire
 out=Path(a.output);bank=dict(np.load(out/'signals.npz'));symbols=tuple(bank['symbols'].tolist());rep=Repertoire(symbols,(6,6))
 target=bank['targets'];records=[]
 p=np.full((len(target),36),1/36) if a.model=='uniform' else np.load(out/(a.model+'_priors.npz'))['p']
 assert len(p)==len(target)
 fusion=PluginFusion({'plugin':'log_pool','params':{'alpha':1,'beta':1}},'on')
 predictions=[]
 for seed in range(5):
  for ri,repetitions in enumerate(bank['repetitions']):
   pred=[]
   for i in range(len(target)):
    prior=SymbolDistribution(rep,np.log(p[i]),a.model,i)
    obs=PhysiologyObservation(i,likelihood_vector(bank['p'][seed,i,ri].tolist(),list(symbols)),'likelihood')
    post=fusion.combine(prior,obs);assert fusion.last_error is None
    pred.append(int(np.argmax(post.log_p)))
   predictions.append(pred)
   records.append({'seed':seed,'repetitions':int(repetitions),'correct':int(np.sum(np.asarray(pred)==target)),'n':len(target),'accuracy':float(np.mean(np.asarray(pred)==target))})
 summary={'model':a.model,'context':'true_prefix','results':records}
 (out/(a.model+'_isolated.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2))
 np.savez_compressed(out/(a.model+'_isolated.npz'),predictions=np.asarray(predictions).reshape(5,3,-1))
 print(a.model,{int(r):round(100*np.mean([x['accuracy'] for x in records if x['repetitions']==r]),2) for r in bank['repetitions']})
if __name__=='__main__':
 p=argparse.ArgumentParser()
 for key in ('speller','model','output'):p.add_argument('--'+key,required=True)
 main(p.parse_args())
