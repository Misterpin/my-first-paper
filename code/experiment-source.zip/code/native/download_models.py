"""Download fixed public model revisions; no authentication or remote code needed."""
import argparse,hashlib,json,shutil
from pathlib import Path
from huggingface_hub import hf_hub_download,HfApi
SPECS=[('kenlm','jonatasgrosman/wav2vec2-large-xlsr-53-russian','2329100508896c6d9b157019803ab5601e6f3406',['language_model/lm.binary','language_model/unigrams.txt']),('qwen-base','Qwen/Qwen2.5-0.5B','060db6499f32faf8b98477b0a26969ef7d8b9987',['config.json','generation_config.json','merges.txt','model.safetensors','tokenizer.json','tokenizer_config.json','vocab.json','LICENSE'])]
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--models',nargs='+',choices=['kenlm','qwen-base'],default=['kenlm']);a=p.parse_args();root=Path(a.output);records=[]
 for name,repo,sha,files in SPECS:
  if name not in a.models:continue
  folder=root/name;folder.mkdir(parents=True,exist_ok=True)
  info=HfApi().model_info(repo,revision=sha,files_metadata=True);metadata={s.rfilename:s for s in info.siblings}
  for file in files:
   dest=folder/Path(file).name
   src=hf_hub_download(repo,file,revision=sha,local_dir=folder)
   if Path(src).resolve()!=dest.resolve():shutil.move(src,dest)
   h=hashlib.sha256()
   with dest.open('rb') as f:
    for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
   digest=h.hexdigest();expected=getattr(metadata[file].lfs,'sha256',None)
   if expected and expected!=digest:raise RuntimeError(f'Checksum mismatch: {dest}')
   records.append({'repo':repo,'revision':sha,'file':file,'sha256':digest,'size':dest.stat().st_size})
   print(name,file,'verified',flush=True)
 (root/'download-manifest.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
