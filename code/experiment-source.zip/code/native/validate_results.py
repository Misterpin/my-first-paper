"""Audit saved complete runs: sources, correction-off, texts, and native fusion."""
import argparse,json,hashlib
from pathlib import Path
import numpy as np
from common import setup
p=argparse.ArgumentParser();p.add_argument('--speller',required=True);p.add_argument('--results',required=True);a=p.parse_args();setup(a.speller)
from eeg_speller.external.controller import likelihood_vector
from eeg_speller.core.distributions import normalize_logits
root=Path(a.results);report={}
for name in ('uniform','ngram','kenlm','hf_causal'):
 file=root/(name+'_sessions.jsonl')
 if not file.exists():continue
 records=[json.loads(x) for x in file.read_text().splitlines()];assert len(records)==200
 inspected=0;epochs=0;maxdiff=0
 for row in records:
  assert row['end_reason']=='target_finished' and row['integrity_complete']
  d=root/row['directory'];manifest=json.loads((d/'session.json').read_text())
  assert manifest['models']['slow_llm']['backend']=='disabled'
  assert manifest['counts']['corrections']==0
  assert (d/'texts/primary_final.txt').read_text()==row['text']
  assert (d/'texts/secondary_final.txt').read_text()==row['text']
  # One complete phrase per seed and model is audited independently of the plugin.
  if row['id']!='T01':continue
  states={};symbols=manifest['repertoire']
  for event in map(json.loads,(d/'events.jsonl').read_text().splitlines()):
   eid=event['epoch_id'];typ=event['type'];payload=event['payload'];state=states.setdefault(eid,{})
   if typ=='prior_computed':state['prior']=np.array(payload['log_p'])
   elif typ=='physiology_observation':state['likelihood']=likelihood_vector(payload['raw'],symbols)
   elif typ=='posterior_computed':
    expected=normalize_logits(state['prior']+state['likelihood']);got=np.array(payload['log_p']);diff=float(np.max(np.abs(expected-got)))
    assert diff<1e-10;maxdiff=max(maxdiff,diff);epochs+=1
  inspected+=1
 report[name]={'sessions':len(records),'all_completed':True,'all_correction_off':True,'fusion_audited_phrases':inspected,'fusion_audited_epochs':epochs,'max_log_probability_difference':maxdiff}
(root/'validation.json').write_text(json.dumps(report,indent=2));print(report)
