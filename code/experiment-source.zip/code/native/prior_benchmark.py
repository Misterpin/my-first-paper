"""Measure actual .predict adapters; save every probability and latency."""
import argparse,json,time
from pathlib import Path
import numpy as np
from common import setup,phrases,load_model,predict

def run(a):
    root=setup(a.speller)
    model,rep,cfg=load_model(root,a.models,a.model,a.device)
    rows=phrases(a.data)
    if a.limit: rows=rows[:a.limit]
    out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    logs=[]; probabilities=[]
    warm=time.perf_counter();predict(model,rep,'');warm=time.perf_counter()-warm
    for r in rows:
        text=r['text']
        for i,ch in enumerate(text):
            t=time.perf_counter();p=np.exp(predict(model,rep,text[:i]).log_p);lat=(time.perf_counter()-t)*1000
            # Conditional on a text character, excludes the keyboard's fixed delete mass.
            q=p[:-1]/p[:-1].sum(); k=rep.symbols.index(ch); order=np.argsort(-q)
            logs.append({'id':r['id'],'position':i,'target':ch,'bits':float(-np.log2(q[k])),
                         'top1':int(order[0]==k),'top3':int(k in order[:3]),'latency_ms':lat})
            probabilities.append(p)
        print(a.model,r['id'],len(logs),flush=True)
    lat=[r['latency_ms'] for r in logs]
    summary={'model':a.model,'chars':len(logs),'phrases':len(rows),'bpc':float(np.mean([r['bits'] for r in logs])),
             'top1':float(np.mean([r['top1'] for r in logs])),'top3':float(np.mean([r['top3'] for r in logs])),
             'latency_p50_ms':float(np.median(lat)),'latency_p95_ms':float(np.percentile(lat,95)),
             'warmup_s':warm,'device':a.device,'config':cfg.fast_llm}
    (out/(a.model+'_prior.json')).write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    (out/(a.model+'_characters.jsonl')).write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in logs)+'\n')
    np.savez_compressed(out/(a.model+'_priors.npz'),p=np.asarray(probabilities),ids=np.array([r['id'] for r in logs]),positions=np.array([r['position'] for r in logs]),symbols=np.array(rep.symbols))
    print(json.dumps(summary,ensure_ascii=False),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--speller',required=True);p.add_argument('--models',required=True)
    p.add_argument('--model',required=True);p.add_argument('--device',default='cpu');p.add_argument('--data',required=True)
    p.add_argument('--output',required=True);p.add_argument('--limit',type=int,default=0);run(p.parse_args())
