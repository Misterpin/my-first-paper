"""Import and configure the unmodified production speller."""
import csv, json, sys
from pathlib import Path
import numpy as np

def setup(speller):
    root=Path(speller).resolve()
    sys.path[:0]=[str(root),str(root/'stimulus_kit'),str(root/'stimulus_kit/examples')]
    return root

def phrases(path, split='test'):
    with open(path,encoding='utf-8') as f:
        return [r for r in csv.DictReader(f,delimiter='\t') if r['split']==split]

def load_model(root, models, kind, device='cpu'):
    from eeg_speller.core.config import load_config
    from eeg_speller.core.distributions import Repertoire
    from eeg_speller.llm.fast import create_fast
    cfg=load_config(root/'configs/ext_default.yaml')
    fast=dict(cfg.fast_llm)
    if kind=='kenlm':
        fast.update(backend='kenlm',model_id=str(Path(models).resolve()/'kenlm'),char_mix=.1,vocab_limit=60000,allow_download=False)
    elif kind=='hf_causal':
        fast.update(backend='hf_causal',model_id=str(Path(models).resolve()/'qwen-base'),allow_download=False,device=device)
    else:
        fast.update(backend='ngram',model_file='ru_char4.npz')
    cfg=cfg.model_copy(update={'fast_llm':fast,'slow_llm':{**cfg.slow_llm,'backend':'off'},'word_prediction':{**cfg.word_prediction,'min_prefix':1000}})
    rep=Repertoire(tuple(cfg.repertoire['symbols']),tuple(cfg.repertoire['layout']))
    model=None if kind=='uniform' else create_fast(fast,root/'data/corpus_ru_fallback.txt')
    return model,rep,cfg

def predict(model,rep,context):
    from eeg_speller.core.distributions import SymbolDistribution,log_probs
    return (model.predict(context,rep) if model is not None else
            SymbolDistribution(rep,log_probs(np.ones(len(rep.symbols))),'uniform',len(context)))
