"""Tables/figure only: reads saved measurements; does not run models."""
import argparse,json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties,fontManager

LABELS={'uniform':'Без языка','ngram':'Char4','kenlm':'KenLM','hf_causal':'Qwen 0.5B'}
COLORS={'uniform':'#7a8793','ngram':'#3268b2','kenlm':'#008b75','hf_causal':'#9a5ab5'}
def main(a):
 out=Path(a.results);paper=Path(a.paper);summary={};models=[]
 for model in LABELS:
  file=out/(model+'_isolated.json')
  if file.exists():
   models.append(model);summary[model]={'isolated':json.loads(file.read_text())}
   for name in ['prior','sessions_summary']:
    p=out/(model+'_'+name+'.json')
    if p.exists():summary[model][name]=json.loads(p.read_text())
 rng=np.random.default_rng(20261021);choices=rng.integers(0,40,(10000,40));boot={}
 for model in models:
  p=out/(model+'_sessions.jsonl')
  if not p.exists():continue
  records=[json.loads(s) for s in p.read_text().splitlines()];ids=sorted(set(r['id'] for r in records))
  if len(records)!=200:continue
  assert all(r['end_reason']=='target_finished' and r['integrity_complete'] for r in records)
  edits=np.array([sum(r['edits'] for r in records if r['id']==key) for key in ids]);n=np.array([sum(r['n'] for r in records if r['id']==key) for key in ids])
  boot[model]=edits[choices].sum(1)/n[choices].sum(1)
  summary[model]['CER_CI95']=np.percentile(boot[model],[2.5,97.5]).tolist()
 for model in boot:
  if model!='uniform':summary[model]['CER_reduction_pp_CI95']=np.percentile(100*(boot['uniform']-boot[model]),[2.5,97.5]).tolist()
 if 'kenlm' in boot:
  summary['kenlm']['CER_reduction_vs_Char4_pp_CI95']=np.percentile(100*(boot['ngram']-boot['kenlm']),[2.5,97.5]).tolist()
 (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
 font=paper.parent/'fonts/NotoSans-Regular.ttf';fontManager.addfont(str(font));plt.rcParams.update({'font.family':FontProperties(fname=str(font)).get_name(),'font.size':12,'axes.spines.top':False,'axes.spines.right':False})
 fig,axes=plt.subplots(1,2,figsize=(8.6,3.2),gridspec_kw={'width_ratios':[1.15,1]})
 for model in models:
  rs=summary[model]['isolated']['results'];y=[100*np.mean([r['accuracy'] for r in rs if r['repetitions']==k]) for k in [1,3,5]]
  axes[0].plot([1,3,5],y,'o-',label=LABELS[model],color=COLORS[model],lw=2,markersize=4)
 axes[0].set(xticks=[1,3,5],ylim=(0,100),xlabel='Повторения строк и столбцов',ylabel='Верно выбранные символы, %',title='Правильная история');axes[0].grid(axis='y',alpha=.15);axes[0].legend(frameon=False,fontsize=10,loc='lower right')
 done=[m for m in models if m in boot]
 for i,m in enumerate(done):
  value=100*summary[m]['sessions_summary']['CER'];lo,hi=np.array(summary[m]['CER_CI95'])*100
  axes[1].bar(i,value,color=COLORS[m],width=.62)
  axes[1].errorbar(i,value,yerr=[[value-lo],[hi-value]],color='#263747',capsize=3,fmt='none',lw=1)
  axes[1].text(i,hi+.6,f'{value:.2f}',ha='center',fontsize=10)
 axes[1].set(xticks=range(len(done)),xticklabels=[LABELS[m] for m in done],ylabel='CER, % (меньше — лучше)',title='Собственная история, R = 5',ylim=(0,max(28,max(100*summary[m]['CER_CI95'][1] for m in done)+5)))
 axes[1].grid(axis='y',alpha=.15);axes[1].set_axisbelow(True)
 fig.tight_layout(w_pad=2);(paper/'figures').mkdir(exist_ok=True);fig.savefig(paper/'figures/native_main.pdf',bbox_inches='tight');fig.savefig(paper/'figures/native_main.png',dpi=180,bbox_inches='tight');plt.close(fig)
 def f(v,n=2):return f'{v:.{n}f}'.replace('.',',')
 base=summary['uniform']['sessions_summary']['CER'];char=summary['ngram']['sessions_summary']['CER']
 acc=lambda m:100*np.mean([r['accuracy'] for r in summary[m]['isolated']['results'] if r['repetitions']==5])
 macros={'BaseAcc':acc('uniform'),'CharAcc':acc('ngram'),'BaseCER':base*100,'CharCER':char*100,'CharGain':acc('ngram')-acc('uniform'),'CharRel':100*(base-char)/base}
 ken=summary['kenlm']['sessions_summary']['CER']
 macros.update({'KenAcc':acc('kenlm'),'KenCER':ken*100,'KenGain':acc('kenlm')-acc('uniform'),'KenRel':100*(base-ken)/base,'KenOverChar':100*(char-ken)})
 (paper/'native_values.tex').write_text('\n'.join('\\newcommand{\\'+k+'}{'+f(v)+'}' for k,v in macros.items())+'\n')
 lines=[r'\begin{table}[h]',r'\caption{Измерения на новых фразах. BPC и Top-1: правильная история; CER: собственная история. Медиана/p95 — задержка prior, мс.}',r'\small\centering',r'\begin{tabular}{@{}lrrrr@{}}\toprule',r'Источник & BPC $\downarrow$ & Top-1, \% $\uparrow$ & CER, \% $\downarrow$ & Медиана/p95 \\\midrule']
 for m in models:
  s=summary[m];prior=s.get('prior');cer=s.get('sessions_summary',{}).get('CER');cells=[LABELS[m],f(prior['bpc']) if prior else f(np.log2(35)),f(100*prior['top1']) if prior else '--',f(cer*100) if cer is not None else '--',(f(prior['latency_p50_ms'])+'/'+f(prior['latency_p95_ms'])) if prior else '--']
  lines.append(' & '.join(cells)+r' \\')
 lines += [r'\bottomrule\end{tabular}',r'\end{table}'];(paper/'native_table.tex').write_text('\n'.join(lines)+'\n')
 ci=summary['ngram']['CER_reduction_pp_CI95']
 ki=summary['kenlm']['CER_reduction_pp_CI95'];kc=summary['kenlm']['CER_reduction_vs_Char4_pp_CI95']
 text=f"Парный bootstrap по 40 фразам (10\\,000 выборок) даёт 95\\%-е интервалы снижения CER относительно режима без языка: Char4 [{f(ci[0])}; {f(ci[1])}], KenLM [{f(ki[0])}; {f(ki[1])}] п.\\,п. Разница Char4 минус KenLM равна {f(100*(char-ken))} п.\\,п.; её интервал [{f(kc[0])}; {f(kc[1])}] включает ноль. Все 600 сессий завершены; выигрыш обеих моделей относительно режима без языка подтверждён парным сравнением."
 (paper/'native_discussion.tex').write_text(text+'\n')
 (paper/'native_conclusion.tex').write_text('KenLM даёт наименьшую наблюдаемую CER: \\KenCER\\%, на \\KenRel\\% ниже режима без языка. Для Char4 снижение составляет \\CharRel\\%. У KenLM также лучше BPC и Top-1, но выше 95-й перцентиль задержки: 56,57 мс против 0,03 мс у Char4. Поэтому качество источника, итоговый текст и вычислительная задержка представлены раздельно.\n')
 print({m:s.get('sessions_summary',{}).get('CER') for m,s in summary.items()})
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--results',required=True);p.add_argument('--paper',required=True);main(p.parse_args())
