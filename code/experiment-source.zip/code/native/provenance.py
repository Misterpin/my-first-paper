"""Record code, model and data checksums without modifying the speller."""
import argparse,hashlib,importlib.metadata,json,platform,subprocess,sys
from pathlib import Path
from download_models import SPECS
p=argparse.ArgumentParser();p.add_argument('--speller',required=True);p.add_argument('--models',required=True);p.add_argument('--output',required=True);p.add_argument('--model-kinds',nargs='+',default=['kenlm']);a=p.parse_args()
source=Path(a.speller).resolve();models=Path(a.models).resolve();out=Path(a.output);code=Path(__file__).resolve().parent.parent

def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
try:commit=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True).strip()
except subprocess.CalledProcessError:commit=None
record={'python':sys.version,'platform':platform.platform(),'machine':platform.machine(),'speller_commit':commit,
 'packages':{k:importlib.metadata.version(k) for k in ['numpy','torch','transformers','kenlm','pylsl','pygame','pydantic','matplotlib']},
 'source_files':{},'models':{},'inputs':{}}
for file in ['eeg_speller/external/controller.py','eeg_speller/llm/backends/char_ngram.py','eeg_speller/llm/backends/kenlm_words.py','eeg_speller/llm/backends/hf_causal.py','inference/log_pool.py','stimulus_kit/examples/headless_sim.py','models/ngram/ru_char4.npz']:
 record['source_files'][file]=sha(source/file)
for kind,repo,revision,files in SPECS:
 if kind not in a.model_kinds:continue
 record['models'][kind]={'repository':repo,'revision':revision,'files':{}}
 for file in files:
  f=models/kind/Path(file).name
  if f.exists():record['models'][kind]['files'][file]={'bytes':f.stat().st_size,'sha256':sha(f)}
for f in [code/'data/phrases.tsv',code/'native/protocol.json',out/'signals.npz']:
 record['inputs'][f.name]=sha(f)
(out/'provenance.json').write_text(json.dumps(record,ensure_ascii=False,indent=2));print('Provenance written')
