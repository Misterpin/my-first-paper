"""Collect outputs from the shipped simulator; only its wall clock is accelerated.
The target phrase belongs to this simulated participant. Source models never see it.
"""
import argparse,json,itertools
from pathlib import Path
from unittest.mock import patch
import numpy as np
from common import setup,phrases,load_model

def main(a):
 root=setup(a.speller)
 import headless_sim
 from speller_link import Epoch
 _,rep,_=load_model(root,a.models,'uniform')
 rows=phrases(a.data);values=[];targets=[];ids=[]
 class Capture:
  def __init__(self,text):self.text=text;self.i=-1;self.current=[];self.count=0;self.rows=[]
  def wait_epoch(self,timeout):
   self.i+=1
   if self.i>=len(self.text):return None
   self.count=0;self.current=[]
   return Epoch({'epoch':self.i,'symbols':rep.symbols,'layout':rep.layout,'text':self.text[:self.i],'settings':{}})
  def flash(self,group,timestamp):self.count+=1
  def send_likelihood(self,p,final=False):
   if not final and self.count in (12,36,60):self.current.append([p[s] for s in rep.symbols])
  def should_stop(self):return False
  def done(self):self.rows.append(self.current)
  def wait_result(self,timeout):return None
 for seed in range(a.seeds):
  per_seed=[]
  for ri,r in enumerate(rows):
   link=Capture(r['text'])
   # Scheduling is irrelevant to score generation; keep the original simulator math.
   counter=itertools.count(0,1)
   with patch.object(headless_sim,'now',lambda:float(next(counter))):
    headless_sim.run(r['text'],d_prime=1.2,flash_ms=1,isi_ms=0,repetitions=5,
                     seed=seed*10000+ri,link=link,verbose=False)
   per_seed.extend(link.rows)
   if seed==0:
    targets.extend([rep.symbols.index(c) for c in r['text']]);ids.extend([r['id']]*len(r['text']))
  values.append(per_seed);print('seed',seed,'positions',len(per_seed),flush=True)
 out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
 np.savez_compressed(out/'signals.npz',p=np.asarray(values,dtype=np.float64),targets=np.array(targets),ids=np.array(ids),symbols=np.array(rep.symbols),repetitions=np.array([1,3,5]))
 print('saved',np.asarray(values).shape,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser()
 for key in ('speller','models','data','output'):p.add_argument('--'+key,required=True)
 p.add_argument('--seeds',type=int,default=30)
 main(p.parse_args())
