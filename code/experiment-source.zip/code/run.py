"""Single entry point for the native BioSpeller study; see docs/REPRODUCIBILITY.md."""
import argparse,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--speller',required=True);p.add_argument('--models',required=True)
p.add_argument('--models-to-run',nargs='+',default=['uniform','ngram','kenlm'])
p.add_argument('--device',default='cpu',choices=['cpu','mps','cuda'])
p.add_argument('--stage',choices=['signals','priors','decode','sessions','plots','all'],default='all')
a=p.parse_args();root=Path(__file__).resolve().parent;out=root/'results/native';data=root/'data/phrases.tsv'
def call(script,*args):subprocess.run([sys.executable,str(root/'native'/script),*map(str,args)],check=True)
if a.stage in ('signals','all'):
 call('signal_bank.py','--speller',a.speller,'--models',a.models,'--data',data,'--output',out)
for model in a.models_to_run:
 common=['--speller',a.speller,'--model',model,'--output',out]
 if a.stage in ('priors','all') and model!='uniform':
  call('prior_benchmark.py',*common,'--models',a.models,'--data',data,'--device',a.device if model=='hf_causal' else 'cpu')
 if a.stage in ('decode','all'):call('isolated_decode.py',*common)
 if a.stage in ('sessions','all'):
  call('session_replay.py',*common,'--models',a.models,'--data',data,'--device',a.device if model=='hf_causal' else 'cpu')
if a.stage in ('plots','all'):
 call('plot_results.py','--results',out,'--paper',root.parent/'paper')
 call('validate_results.py','--speller',a.speller,'--results',out)
 call('provenance.py','--speller',a.speller,'--models',a.models,'--output',out)
